package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginPage {

	// Encapsulation = private data + Public methods

	private WebDriver driver;

	// Initialization driver
	// for initialization part we need constructor

	public LoginPage(WebDriver driver) {

		this.driver = driver;

		// calling initElement()
		PageFactory.initElements(driver, this);

		// for current page reference writing this keyword this will initialize page

	}

	// locators
	@FindBy(id = "user-name")
	private WebElement username;

	@FindBy(id = "password")
	private WebElement password;

	@FindBy(id = "login-button")
	private WebElement loginbutton;

	public void verifyTitle() {

		String actualTitle = driver.getTitle();
		Assert.assertTrue(actualTitle.contains("Lab"), "Title is Not Matching");
		System.out.println("Title is Matching..! " + actualTitle);
	}

	public void verifyLogin(String un, String pwd) {
		username.sendKeys(un);
		password.sendKeys(pwd);
		loginbutton.click();
		Assert.assertTrue(driver.getCurrentUrl().contains("inventory"), "Login Failed");
		System.out.println("Login Sucessful..!");
	}

}
