package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class ProductsPage {

	private WebDriver driver;

	public ProductsPage(WebDriver driver) {
		this.driver = driver;

		// calling initElement()
		PageFactory.initElements(driver, this);
	}

	// locators

	@FindBy(className = "product_sort_container")
	private WebElement sortdropdown;

	@FindBy(id = "item_4_title_link")
	private WebElement product;

	public void verifyselectdropdown() {

		Select ddl = new Select(sortdropdown);
		ddl.selectByIndex(3);
		String sorttext = sortdropdown.getText();
		Assert.assertTrue(sorttext.contains("Price"), "Sorting is not Matching..!");
		System.out.println("Sorting is Matching..!");

	}

	public void verifyselectitem() {

		String e = product.getText();
		product.click();
		Assert.assertTrue(e.contains("Backpack"), "Product is not Matching..!");
		System.out.println("Product is Matching..!");

	}

}
