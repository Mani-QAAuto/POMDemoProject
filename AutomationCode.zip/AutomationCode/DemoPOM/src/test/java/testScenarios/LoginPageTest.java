package testScenarios;

import org.testng.annotations.Test;

import base.BaseClass;
import utilities.ReadXLSdata;

public class LoginPageTest extends BaseClass {

	@Test(priority = 1)
	public void verifyTitle() {
		login.verifyTitle();
	}

	@Test(dataProviderClass = ReadXLSdata.class, dataProvider = "exceltestdata", priority = 2)
	public void verifyLogin(String username, String password) {

		login.verifyLogin(username, password);
	}
}
