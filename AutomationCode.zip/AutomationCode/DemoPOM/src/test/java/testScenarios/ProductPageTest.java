package testScenarios;

import org.testng.annotations.Test;

import base.BaseClass;
import utilities.ReadXLSdata;

public class ProductPageTest extends BaseClass {

	@Test(dataProviderClass = ReadXLSdata.class, dataProvider = "exceltestdata")
	public void verifyLogin(String username, String password) {

		login.verifyLogin(username, password);
	}

	@Test
	public void verifyselectdropdown() {
		products.verifyselectdropdown();
	}

	@Test
	public void verifyselectitem() {
		products.verifyselectitem();
	}

}
