package base;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import pages.LoginPage;
import pages.ProductsPage;

public class BaseClass {

	public WebDriver driver;
	public LoginPage login;
	public ProductsPage products;

	@BeforeTest
	public void setUp() {

		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		driver.get("https://www.saucedemo.com/v1/index.html");
		driver.manage().window().maximize();
		login = new LoginPage(driver);
		products = new ProductsPage(driver);

	}

	@AfterTest
	public void TearDown() {

		driver.quit();
	}

}
